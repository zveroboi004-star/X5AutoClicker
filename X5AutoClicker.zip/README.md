# X5AutoClicker

Обучаемый автокликер для X5 Курьер.

## Возможности v1
- Старт / Стоп
- Выбор сценария
- Запись последовательности нажатий
- Повторение сценария
- Настраиваемый интервал
- Остановка при появлении заданного текста
- Android Accessibility Service

## GitHub Actions
В папке `.github/workflows/` уже находится готовый workflow для автоматической сборки APK.

После загрузки проекта на GitHub:
**Actions → Build X5 Auto Clicker APK → Run workflow**

Готовый APK появится в разделе **Artifacts**.
