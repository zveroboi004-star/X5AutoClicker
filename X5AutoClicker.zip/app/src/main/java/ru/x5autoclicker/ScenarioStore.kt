package ru.x5autoclicker

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import android.graphics.Rect

object ScenarioStore {
    private const val PREF = "scenarios"
    private const val KEY = "data"

    fun load(context: Context): MutableList<Scenario> {
        val raw = context.getSharedPreferences(PREF, 0).getString(KEY, null) ?: return mutableListOf(
            Scenario("Ловля магазина №1")
        )
        val out = mutableListOf<Scenario>()
        val arr = JSONArray(raw)
        for (i in 0 until arr.length()) {
            val s = arr.getJSONObject(i)
            val actions = mutableListOf<RecordedAction>()
            val aa = s.optJSONArray("actions") ?: JSONArray()
            for (j in 0 until aa.length()) {
                val a = aa.getJSONObject(j)
                actions += RecordedAction(
                    a.optString("text").takeIf { it.isNotEmpty() },
                    a.optString("desc").takeIf { it.isNotEmpty() },
                    a.optString("class").takeIf { it.isNotEmpty() },
                    Rect(a.optInt("l"), a.optInt("t"), a.optInt("r"), a.optInt("b")),
                    a.optLong("delay", 500L)
                )
            }
            out += Scenario(s.getString("name"), s.optLong("interval",1000), s.optString("stopText","Московская область, Егорьевск, 4-й мкр, 21А"), actions)
        }
        return out
    }

    fun save(context: Context, list: List<Scenario>) {
        val arr = JSONArray()
        list.forEach { s ->
            val o = JSONObject().apply {
                put("name", s.name); put("interval", s.intervalMs); put("stopText", s.stopText)
                val aa = JSONArray()
                s.actions.forEach { a ->
                    aa.put(JSONObject().apply {
                        put("text", a.text ?: ""); put("desc", a.description ?: "")
                        put("class", a.className ?: "")
                        put("l", a.bounds.left); put("t", a.bounds.top)
                        put("r", a.bounds.right); put("b", a.bounds.bottom)
                        put("delay", a.delayMs)
                    })
                }
                put("actions", aa)
            }
            arr.put(o)
        }
        context.getSharedPreferences(PREF,0).edit().putString(KEY,arr.toString()).apply()
    }
}
