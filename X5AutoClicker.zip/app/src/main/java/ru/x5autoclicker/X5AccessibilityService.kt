package ru.x5autoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class X5AccessibilityService : AccessibilityService() {
    companion object { var instance: X5AccessibilityService? = null }
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    @Volatile private var recording = false
    private var scenario: Scenario? = null
    private var index = 0
    private var repeats = 0
    private var lastRecordAt = 0L
    private var pending: RecordedAction? = null

    override fun onServiceConnected() { super.onServiceConnected(); instance = this }
    override fun onDestroy() { stop(); instance = null; super.onDestroy() }
    override fun onInterrupt() { stop() }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val root = rootInActiveWindow ?: return

        // Stop condition: search visible text recursively.
        scenario?.stopText?.takeIf { it.isNotBlank() }?.let { stopText ->
            if (findText(root, stopText)) {
                stop()
                return
            }
        }

        if (!running && recording && event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
            val node = event.source ?: return
            val now = System.currentTimeMillis()
            val delay = if (lastRecordAt == 0L) 0L else now - lastRecordAt
            val r = Rect()
            node.getBoundsInScreen(r)
            pending = RecordedAction(
                node.text?.toString(),
                node.contentDescription?.toString(),
                node.className?.toString(),
                r,
                delay.coerceIn(0, 60000)
            )
            lastRecordAt = now
            scenario?.actions?.add(pending!!)
            node.recycle()
        }
    }

    fun start(s: Scenario) {
        // START is playback only: never allow recording while the clicker is running.
        recording = false
        lastRecordAt = 0L
        scenario = s; running = true; index = 0; repeats = 0
        handler.removeCallbacksAndMessages(null)
        runNext()
    }

    fun startRecording(s: Scenario) {
        stop()
        scenario = s
        s.actions.clear()
        recording = true
        lastRecordAt = 0L
    }

    fun stopRecording() { recording = false; lastRecordAt = 0L }
    fun getRepeats() = repeats
    fun isRunning() = running
    fun isRecording() = recording

    fun stop() {
        // STOP is playback only and always cancels any pending work.
        running = false
        recording = false
        lastRecordAt = 0L
        handler.removeCallbacksAndMessages(null)
    }

    private fun runNext() {
        if (!running) return
        val s = scenario ?: return
        if (s.actions.isEmpty()) { stop(); return }
        val a = s.actions[index]
        val delay = if (index == 0) 0L else a.delayMs
        handler.postDelayed({
            if (!running) return@postDelayed
            performAction(a)
            index++
            if (index >= s.actions.size) {
                index = 0; repeats++
                handler.postDelayed({ runNext() }, s.intervalMs.coerceAtLeast(50))
            } else runNext()
        }, delay)
    }

    private fun performAction(a: RecordedAction) {
        val root = rootInActiveWindow ?: return
        val node = findBestNode(root, a)
        if (node != null) {
            var n: AccessibilityNodeInfo? = node
            while (n != null && !n.isClickable) n = n.parent
            if (n?.isClickable == true) n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            node.recycle()
        } else {
            val cx = (a.bounds.left + a.bounds.right) / 2f
            val cy = (a.bounds.top + a.bounds.bottom) / 2f
            val path = Path().apply { moveTo(cx, cy) }
            dispatchGesture(GestureDescription.Builder().addStroke(
                GestureDescription.StrokeDescription(path, 0, 40)
            ).build(), null, null)
        }
    }

    private fun findBestNode(root: AccessibilityNodeInfo, a: RecordedAction): AccessibilityNodeInfo? {
        val text = a.text
        if (!text.isNullOrBlank()) {
            root.findAccessibilityNodeInfosByText(text).firstOrNull()?.let { return it }
        }
        val desc = a.description
        if (!desc.isNullOrBlank()) {
            root.findAccessibilityNodeInfosByText(desc).firstOrNull()?.let { return it }
        }
        return findNear(root, a.bounds, a.className)
    }

    private fun findNear(node: AccessibilityNodeInfo, target: Rect, cls: String?): AccessibilityNodeInfo? {
        val r = Rect(); node.getBoundsInScreen(r)
        if (r.width() > 0 && r.height() > 0 && r.centerX() == target.centerX() && r.centerY() == target.centerY()
            && (cls == null || node.className?.toString() == cls)) return AccessibilityNodeInfo.obtain(node)
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                val found = findNear(child, target, cls)
                child.recycle()
                if (found != null) return found
            }
        }
        return null
    }

    private fun findText(node: AccessibilityNodeInfo, wanted: String): Boolean {
        val t = node.text?.toString() ?: ""
        val d = node.contentDescription?.toString() ?: ""
        if (t.contains(wanted, true) || d.contains(wanted, true)) return true
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                val found = findText(child, wanted)
                child.recycle()
                if (found) return true
            }
        }
        return false
    }

    private fun <T> AccessibilityNodeInfo.findFirst(predicate: (AccessibilityNodeInfo) -> T?): T? = null
}
