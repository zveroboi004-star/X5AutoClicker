package ru.x5autoclicker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class X5AccessibilityService : AccessibilityService() {

    private enum class Mode { IDLE, TRAINING, PLAYBACK }

    @Volatile
    private var mode: Mode = Mode.IDLE

    companion object {
        @Volatile
        var instance: X5AccessibilityService? = null
    }

    private val handler = Handler(Looper.getMainLooper())

    @Volatile
    private var running = false

    private var scenario: Scenario? = null
    private var actionIndex = 0
    private var repeats = 0
    private var lastRecordAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        stop()
        instance = null
        super.onDestroy()
    }

    override fun onInterrupt() {
        stop()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val root = rootInActiveWindow ?: return

        // Условие остановки относится только к выполнению сохранённого сценария.
        // Во время обучения появление адреса не должно неожиданно завершать запись.
        if (mode == Mode.PLAYBACK) {
            val stopText = scenario?.stopText.orEmpty()
            if (stopText.isNotBlank() && containsText(root, stopText)) {
                stop()
                return
            }
        }

        if (mode != Mode.TRAINING || event.eventType != AccessibilityEvent.TYPE_VIEW_CLICKED) {
            return
        }

        val source = event.source ?: return
        val node = AccessibilityNodeInfo.obtain(source)
        try {
            val now = System.currentTimeMillis()
            val delay = if (lastRecordAt == 0L) 0L else now - lastRecordAt
            val bounds = Rect()
            node.getBoundsInScreen(bounds)

            scenario?.actions?.add(
                RecordedAction(
                    text = node.text?.toString()?.takeIf { it.isNotBlank() },
                    description = node.contentDescription?.toString()?.takeIf { it.isNotBlank() },
                    className = node.className?.toString(),
                    bounds = Rect(bounds),
                    delayMs = delay.coerceIn(0L, 60000L)
                )
            )
            lastRecordAt = now
        } finally {
            node.recycle()
        }
    }

    /** Только обучение. Эта функция никогда не запускается кнопкой выполнения. */
    fun beginTraining(s: Scenario) {
        cancelCurrentOperation()
        scenario = s
        s.actions.clear()
        actionIndex = 0
        repeats = 0
        lastRecordAt = 0L
        mode = Mode.TRAINING
    }

    /** Только выполнение. Эта функция не связана с обучением. */
    fun beginPlayback(s: Scenario): Boolean {
        cancelCurrentOperation()

        if (s.actions.isEmpty()) {
            scenario = s
            mode = Mode.IDLE
            return false
        }

        scenario = s
        actionIndex = 0
        repeats = 0
        mode = Mode.PLAYBACK
        running = true
        runNext()
        return true
    }

    /** Универсальная остановка текущей операции. Не включает обучение. */
    fun cancelCurrentOperation() {
        running = false
        mode = Mode.IDLE
        handler.removeCallbacksAndMessages(null)
        actionIndex = 0
        repeats = 0
        lastRecordAt = 0L
    }

    fun finishTraining() {
        if (mode == Mode.TRAINING) {
            mode = Mode.IDLE
            lastRecordAt = 0L
        }
    }

    fun isTraining(): Boolean = mode == Mode.TRAINING

    fun isRunning(): Boolean = mode == Mode.PLAYBACK && running

    fun stop() {
        cancelCurrentOperation()
    }

    private fun runNext() {
        if (mode != Mode.PLAYBACK || !running) return

        val s = scenario ?: run {
            stop()
            return
        }

        if (s.actions.isEmpty()) {
            stop()
            return
        }

        if (actionIndex !in s.actions.indices) {
            actionIndex = 0
        }

        val action = s.actions[actionIndex]
        val delay = if (actionIndex == 0) 0L else action.delayMs.coerceIn(0L, 60000L)

        handler.postDelayed({
            if (mode != Mode.PLAYBACK || !running) return@postDelayed

            performAction(action)
            actionIndex++

            if (actionIndex >= s.actions.size) {
                actionIndex = 0
                repeats++
                val interval = s.intervalMs.coerceIn(50L, 60000L)
                handler.postDelayed({ runNext() }, interval)
            } else {
                runNext()
            }
        }, delay)
    }

    private fun performAction(action: RecordedAction) {
        val root = rootInActiveWindow
        val node = root?.let { findBestNode(it, action) }

        if (node != null) {
            try {
                if (clickNodeOrParent(node)) return
            } finally {
                node.recycle()
            }
        }

        // Надёжный запасной вариант: нажимаем в сохранённый центр элемента.
        val cx = (action.bounds.left + action.bounds.right) / 2f
        val cy = (action.bounds.top + action.bounds.bottom) / 2f
        if (cx >= 0f && cy >= 0f) {
            val path = Path().apply { moveTo(cx, cy) }
            dispatchGesture(
                GestureDescription.Builder()
                    .addStroke(GestureDescription.StrokeDescription(path, 0L, 40L))
                    .build(),
                null,
                null
            )
        }
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        val parents = mutableListOf<AccessibilityNodeInfo>()

        try {
            while (current != null) {
                if (current.isClickable || current.isFocusable) {
                    return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                }

                val parent = current.parent
                if (parent == null) break
                parents += parent
                current = parent
            }
            return false
        } finally {
            parents.forEach { it.recycle() }
        }
    }

    private fun findBestNode(root: AccessibilityNodeInfo, action: RecordedAction): AccessibilityNodeInfo? {
        val text = action.text?.trim().orEmpty()
        if (text.isNotEmpty()) {
            val matches = root.findAccessibilityNodeInfosByText(text)
            val exact = matches.firstOrNull { it.text?.toString()?.trim() == text }
            if (exact != null) {
                matches.filter { it !== exact }.forEach { it.recycle() }
                return exact
            }
            matches.firstOrNull()?.let { selected ->
                matches.filter { it !== selected }.forEach { it.recycle() }
                return selected
            }
        }

        val description = action.description?.trim().orEmpty()
        if (description.isNotEmpty()) {
            val matches = root.findAccessibilityNodeInfosByText(description)
            val exact = matches.firstOrNull {
                it.contentDescription?.toString()?.trim() == description ||
                    it.text?.toString()?.trim() == description
            }
            if (exact != null) {
                matches.filter { it !== exact }.forEach { it.recycle() }
                return exact
            }
            matches.firstOrNull()?.let { selected ->
                matches.filter { it !== selected }.forEach { it.recycle() }
                return selected
            }
        }

        return findNearestNode(root, action.bounds, action.className)
    }

    private fun findNearestNode(
        root: AccessibilityNodeInfo,
        target: Rect,
        className: String?
    ): AccessibilityNodeInfo? {
        var best: AccessibilityNodeInfo? = null
        var bestDistance = Long.MAX_VALUE

        fun visit(node: AccessibilityNodeInfo) {
            val bounds = Rect()
            node.getBoundsInScreen(bounds)
            if (!bounds.isEmpty()) {
                val classMatches = className.isNullOrBlank() || node.className?.toString() == className
                if (classMatches) {
                    val dx = bounds.centerX().toLong() - target.centerX()
                    val dy = bounds.centerY().toLong() - target.centerY()
                    val distance = dx * dx + dy * dy
                    if (distance < bestDistance) {
                        best?.recycle()
                        best = AccessibilityNodeInfo.obtain(node)
                        bestDistance = distance
                    }
                }
            }

            for (i in 0 until node.childCount) {
                val child = node.getChild(i) ?: continue
                try {
                    visit(child)
                } finally {
                    child.recycle()
                }
            }
        }

        visit(root)
        return best
    }

    private fun containsText(node: AccessibilityNodeInfo, wanted: String): Boolean {
        val target = normalize(wanted)
        if (target.isBlank()) return false

        val text = normalize(node.text?.toString().orEmpty())
        val description = normalize(node.contentDescription?.toString().orEmpty())
        if (text.contains(target, ignoreCase = true) || description.contains(target, ignoreCase = true)) {
            return true
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            try {
                if (containsText(child, wanted)) return true
            } finally {
                child.recycle()
            }
        }
        return false
    }

    private fun normalize(value: String): String = value
        .replace('ё', 'е')
        .replace('Ё', 'Е')
        .replace(Regex("\\s+"), " ")
        .trim()
}
