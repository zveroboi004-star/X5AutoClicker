package ru.x5autoclicker

import android.graphics.Rect

data class RecordedAction(
    val text: String?,
    val description: String?,
    val className: String?,
    val bounds: Rect,
    val delayMs: Long
)

data class Scenario(
    var name: String,
    var intervalMs: Long = 1000L,
    var stopText: String = "Московская область, Егорьевск, 4-й мкр, 21А",
    val actions: MutableList<RecordedAction> = mutableListOf()
)
