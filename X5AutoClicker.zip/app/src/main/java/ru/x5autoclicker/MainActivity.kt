package ru.x5autoclicker

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var spinner: Spinner
    private lateinit var status: TextView
    private lateinit var info: TextView
    private lateinit var finishTrainingButton: Button
    private lateinit var editScenarioButton: Button
    private lateinit var scenarios: MutableList<Scenario>
    private var activeToast: Toast? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        scenarios = ScenarioStore.load(this)
        spinner = findViewById(R.id.scenarioSpinner)
        status = findViewById(R.id.status)
        info = findViewById(R.id.info)
        finishTrainingButton = findViewById(R.id.finishTrainingButton)
        editScenarioButton = findViewById(R.id.editScenarioButton)
        refreshSpinner()
        updateActionInfo()

        findViewById<Button>(R.id.trainButton).setOnClickListener {
            if (!isAccessibilityEnabled()) {
                Toast.makeText(this, "Включи службу специальных возможностей.", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                return@setOnClickListener
            }
            val s = scenarios[spinner.selectedItemPosition]
            // Обучение нельзя запускать поверх выполнения сценария.
            X5AccessibilityService.instance?.stop()
            X5AccessibilityService.instance?.startRecording(s)
            finishTrainingButton.visibility = android.view.View.VISIBLE
            status.text = "● ИДЕТ ОБУЧЕНИЕ"
            updateActionInfo()
            showToast("ОБУЧЕНИЕ: запись началась. Перейди в X5 и выполни нужную последовательность.", Toast.LENGTH_LONG)
        }
        findViewById<Button>(R.id.startScenarioButton).setOnClickListener {
            if (!isAccessibilityEnabled()) {
                Toast.makeText(this, "Включи службу специальных возможностей.", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                return@setOnClickListener
            }
            val s = scenarios[spinner.selectedItemPosition.coerceIn(0, scenarios.lastIndex)]
            if (s.actions.isEmpty()) {
                Toast.makeText(this, "Сначала запиши и сохрани сценарий.", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            // ВЫПОЛНЕНИЕ — отдельный режим. Никакого обучения здесь нет.
            // Отменяем даже старый Toast от обучения, который мог ещё отображаться.
            activeToast?.cancel()
            activeToast = null

            // Принудительно выключаем запись и закрываем UI обучения.
            X5AccessibilityService.instance?.stopRecording()
            finishTrainingButton.visibility = android.view.View.GONE

            // Запускаем только сохранённые действия. start() сам сбрасывает recording=false.
            X5AccessibilityService.instance?.start(s)
            status.text = "● ВЫПОЛНЕНИЕ СЦЕНАРИЯ"
            updateActionInfo()
            showToast("Сценарий запущен. Выполняется сохранённая последовательность.", Toast.LENGTH_SHORT)
        }

        findViewById<Button>(R.id.stopScenarioButton).setOnClickListener {
            activeToast?.cancel()
            activeToast = null
            X5AccessibilityService.instance?.stop()
            finishTrainingButton.visibility = android.view.View.GONE
            status.text = "● СЦЕНАРИЙ ОСТАНОВЛЕН"
            updateActionInfo()
            showToast("Выполнение сценария остановлено", Toast.LENGTH_SHORT)
        }

        finishTrainingButton.setOnClickListener {
            val s = scenarios[spinner.selectedItemPosition]
            X5AccessibilityService.instance?.stopRecording()
            ScenarioStore.save(this, scenarios)
            finishTrainingButton.visibility = android.view.View.GONE
            status.text = "● ГОТОВ — СЦЕНАРИЙ СОХРАНЕН"
            updateActionInfo()
            showToast("Сценарий сохранен: ${s.actions.size} действий", Toast.LENGTH_SHORT)
        }
        findViewById<Button>(R.id.settingsButton).setOnClickListener { showSettings() }
        editScenarioButton.setOnClickListener { showScenarioEditor() }
    }


    private fun showScenarioEditor() {
        val s = scenarios[spinner.selectedItemPosition.coerceIn(0, scenarios.lastIndex)]
        val items = if (s.actions.isEmpty()) {
            arrayOf("Пока нет записанных действий")
        } else {
            s.actions.mapIndexed { i, a ->
                val target = a.text?.takeIf { it.isNotBlank() }
                    ?: a.description?.takeIf { it.isNotBlank() }
                    ?: a.className ?: "Координатное нажатие"
                "${i + 1}. $target — пауза ${a.delayMs} мс"
            }.toTypedArray()
        }

        AlertDialog.Builder(this)
            .setTitle("Редактор: ${s.name}")
            .setItems(items) { _, which ->
                if (s.actions.isNotEmpty()) showActionEditor(s, which)
            }
            .setNeutralButton("Переименовать") { _, _ -> showRenameScenario(s) }
            .setNegativeButton("Удалить сценарий") { _, _ ->
                if (scenarios.size <= 1) {
                    Toast.makeText(this, "Нельзя удалить последний сценарий.", Toast.LENGTH_SHORT).show()
                } else {
                    val pos = spinner.selectedItemPosition
                    scenarios.removeAt(pos)
                    ScenarioStore.save(this, scenarios)
                    refreshSpinner()
                    Toast.makeText(this, "Сценарий удален", Toast.LENGTH_SHORT).show()
                }
            }
            .setPositiveButton("Готово", null)
            .show()
    }

    private fun showActionEditor(s: Scenario, index: Int) {
        if (index !in s.actions.indices) return
        val a = s.actions[index]
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 10, 40, 0)
        }
        val details = TextView(this).apply {
            text = "Текст: ${a.text ?: "—"}\nОписание: ${a.description ?: "—"}\nКласс: ${a.className ?: "—"}\nКоординаты: ${a.bounds.left}, ${a.bounds.top} → ${a.bounds.right}, ${a.bounds.bottom}"
            textSize = 13f
        }
        val delay = EditText(this).apply {
            hint = "Задержка перед действием, мс"
            setText(a.delayMs.toString())
            inputType = 2
        }
        layout.addView(details)
        layout.addView(delay)

        AlertDialog.Builder(this)
            .setTitle("Действие №${index + 1}")
            .setView(layout)
            .setPositiveButton("Сохранить") { _, _ ->
                val newDelay = delay.text.toString().toLongOrNull()?.coerceIn(0, 60000) ?: a.delayMs
                s.actions[index] = a.copy(delayMs = newDelay)
                ScenarioStore.save(this, scenarios)
                Toast.makeText(this, "Действие сохранено", Toast.LENGTH_SHORT).show()
                showScenarioEditor()
            }
            .setNegativeButton("Удалить действие") { _, _ ->
                s.actions.removeAt(index)
                ScenarioStore.save(this, scenarios)
                updateActionInfo()
                Toast.makeText(this, "Действие удалено", Toast.LENGTH_SHORT).show()
                showScenarioEditor()
            }
            .setNeutralButton("Отмена", null)
            .show()
    }

    private fun showRenameScenario(s: Scenario) {
        val input = EditText(this).apply {
            setText(s.name)
            selectAll()
        }
        AlertDialog.Builder(this)
            .setTitle("Название сценария")
            .setView(input)
            .setPositiveButton("Сохранить") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotBlank()) {
                    s.name = name
                    ScenarioStore.save(this, scenarios)
                    refreshSpinner()
                    Toast.makeText(this, "Название изменено", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun refreshSpinner() {
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, scenarios.map { it.name })
        spinner.setSelection(0)
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                updateActionInfo()
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
        }
    }

    private fun updateActionInfo() {
        if (!::info.isInitialized || scenarios.isEmpty()) return
        val s = scenarios[spinner.selectedItemPosition.coerceIn(0, scenarios.lastIndex)]
        info.text = "Записанных действий: ${s.actions.size}\nИнтервал между циклами: ${s.intervalMs} мс"
    }

    private fun showSettings() {
        val s = scenarios[spinner.selectedItemPosition]
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 20, 40, 10)
        }

        val intervalTitle = TextView(this).apply {
            text = "Интервал между циклами"
            textSize = 16f
        }
        val intervalHelp = TextView(this).apply {
            text = "Пауза после полного выполнения записанной последовательности. Чем меньше значение, тем быстрее повторяется сценарий."
            textSize = 13f
            setPadding(0, 4, 0, 8)
        }
        val interval = EditText(this).apply {
            hint = "Например, 1000 мс = 1 секунда"
            setText(s.intervalMs.toString())
            inputType = 2
        }

        val stopTitle = TextView(this).apply {
            text = "Текст для остановки"
            textSize = 16f
            setPadding(0, 16, 0, 0)
        }
        val stopHelp = TextView(this).apply {
            text = "Когда этот текст появляется на экране X5, автокликер сразу прекращает повторение."
            textSize = 13f
            setPadding(0, 4, 0, 8)
        }
        val stop = EditText(this).apply {
            hint = "Например: адрес магазина"
            setText(s.stopText)
        }

        val actionsTitle = TextView(this).apply {
            text = "Записано действий: ${s.actions.size}"
            textSize = 16f
            setPadding(0, 18, 0, 4)
        }
        val actionsHelp = TextView(this).apply {
            text = "Действия записываются автоматически во время обучения. После записи нажми «Закончить обучение и сохранить»."
            textSize = 13f
        }

        layout.addView(intervalTitle)
        layout.addView(intervalHelp)
        layout.addView(interval)
        layout.addView(stopTitle)
        layout.addView(stopHelp)
        layout.addView(stop)
        layout.addView(actionsTitle)
        layout.addView(actionsHelp)

        AlertDialog.Builder(this)
            .setTitle("Настройки сценария «${s.name}»")
            .setView(layout)
            .setPositiveButton("Сохранить") { _, _ ->
                s.intervalMs = interval.text.toString().toLongOrNull()?.coerceAtLeast(50) ?: 1000
                s.stopText = stop.text.toString().trim().ifBlank { "Московская область, Егорьевск, 4-й мкр, 21А" }
                ScenarioStore.save(this, scenarios)
                updateActionInfo()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun showToast(message: String, duration: Int) {
        activeToast?.cancel()
        activeToast = Toast.makeText(this, message, duration)
        activeToast?.show()
    }

    private fun isAccessibilityEnabled(): Boolean {
        val am = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.packageName == packageName }
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) {
            val service = X5AccessibilityService.instance
            val recordingNow = service?.isRecording() == true
            status.text = when {
                recordingNow -> "● ИДЕТ ОБУЧЕНИЕ"
                service?.isRunning() == true -> "● КЛИКЕР РАБОТАЕТ"
                else -> "● ГОТОВ"
            }
            finishTrainingButton.visibility = if (recordingNow) android.view.View.VISIBLE else android.view.View.GONE
        }
        updateActionInfo()
    }
}
