package ru.x5autoclicker

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.accessibility.AccessibilityManager
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var spinner: Spinner
    private lateinit var status: TextView
    private lateinit var info: TextView
    private lateinit var editScenarioButton: Button
    private lateinit var scenarios: MutableList<Scenario>
    private var settingsDialog: AlertDialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        scenarios = ScenarioStore.load(this)
        if (scenarios.isEmpty()) scenarios.add(Scenario("Ловля магазина №1"))

        spinner = findViewById(R.id.scenarioSpinner)
        status = findViewById(R.id.status)
        info = findViewById(R.id.info)
        editScenarioButton = findViewById(R.id.editScenarioButton)
        refreshSpinner()
        updateActionInfo()
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                X5AccessibilityService.instance?.setSelectedScenario(scenarios[position.coerceIn(0, scenarios.lastIndex)])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        // ВАЖНО: эта кнопка запускает только PLAYBACK. Обучения здесь нет.
        findViewById<Button>(R.id.startScenarioButton).setOnClickListener {
            if (!isAccessibilityEnabled()) {
                Toast.makeText(this, "Включи службу специальных возможностей.", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                return@setOnClickListener
            }

            val service = X5AccessibilityService.instance
            if (service == null) {
                Toast.makeText(this, "Служба X5 Auto Clicker не подключена.", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }

            val s = scenarios[spinner.selectedItemPosition.coerceIn(0, scenarios.lastIndex)]
            service.cancelCurrentOperation() // гарантированно выходим из обучения/старого запуска

            if (s.actions.isEmpty()) {
                status.text = "● ГОТОВ"
                updateActionInfo()
                Toast.makeText(this, "В сценарии нет сохранённых действий. Обучи его через Настройки.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (service.beginPlayback(s)) {
                status.text = "● ВЫПОЛНЕНИЕ СЦЕНАРИЯ"
                updateActionInfo()
                Toast.makeText(this, "Сценарий запущен. Действий: ${s.actions.size}", Toast.LENGTH_SHORT).show()
            }
        }

        findViewById<Button>(R.id.stopScenarioButton).setOnClickListener {
            X5AccessibilityService.instance?.stop()
            status.text = "● СЦЕНАРИЙ ОСТАНОВЛЕН"
            updateActionInfo()
            Toast.makeText(this, "Выполнение сценария остановлено", Toast.LENGTH_SHORT).show()
        }

        findViewById<Button>(R.id.settingsButton).setOnClickListener { showSettings() }
        editScenarioButton.setOnClickListener { showScenarioEditor() }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        val position = if (::spinner.isInitialized) spinner.selectedItemPosition.coerceIn(0, scenarios.lastIndex) else 0
        X5AccessibilityService.instance?.setSelectedScenario(scenarios[position])
        X5AccessibilityService.instance?.showQuickMenu()
    }

    override fun onResume() {
        super.onResume()
        X5AccessibilityService.instance?.hideQuickMenu()
        if (::scenarios.isInitialized && scenarios.isNotEmpty() && ::spinner.isInitialized) {
            val position = spinner.selectedItemPosition.coerceIn(0, scenarios.lastIndex)
            X5AccessibilityService.instance?.setSelectedScenario(scenarios[position])
        }
    }

    private fun showSettings() {
        val s = scenarios[spinner.selectedItemPosition.coerceIn(0, scenarios.lastIndex)]
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 20, 40, 10)
        }

        val intervalTitle = TextView(this).apply { text = "Интервал между циклами"; textSize = 16f }
        val intervalHelp = TextView(this).apply {
            text = "Пауза после полного выполнения последовательности."
            textSize = 13f
            setPadding(0, 4, 0, 8)
        }
        val interval = EditText(this).apply {
            hint = "1000 мс = 1 секунда"
            setText(s.intervalMs.toString())
            inputType = 2
        }

        val stopTitle = TextView(this).apply {
            text = "Текст для остановки"
            textSize = 16f
            setPadding(0, 16, 0, 0)
        }
        val stopHelp = TextView(this).apply {
            text = "При появлении адреса на экране X5 выполнение сразу остановится."
            textSize = 13f
            setPadding(0, 4, 0, 8)
        }
        val stop = EditText(this).apply {
            hint = "Адрес магазина"
            setText(s.stopText)
        }

        val actionsTitle = TextView(this).apply {
            text = "Записано действий: ${s.actions.size}"
            textSize = 16f
            setPadding(0, 18, 0, 4)
        }

        val trainButton = Button(this).apply {
            text = "🎓 НАЧАТЬ ОБУЧЕНИЕ"
            setOnClickListener {
                if (!isAccessibilityEnabled()) {
                    Toast.makeText(this@MainActivity, "Включи службу специальных возможностей.", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    return@setOnClickListener
                }
                val service = X5AccessibilityService.instance
                if (service == null) {
                    Toast.makeText(this@MainActivity, "Служба X5 Auto Clicker не подключена.", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }

                // Сохраняем настройки перед обучением.
                s.intervalMs = interval.text.toString().toLongOrNull()?.coerceAtLeast(50) ?: 1000
                s.stopText = stop.text.toString().trim().ifBlank { "Московская область, Егорьевск, 4-й мкр, 21А" }
                ScenarioStore.save(this@MainActivity, scenarios)

                service.beginTraining(s)
                status.text = "● ИДЕТ ОБУЧЕНИЕ"
                updateActionInfo()
                settingsDialog?.dismiss()
                Toast.makeText(this@MainActivity, "Обучение началось. Перейди в X5 и выполни нужные нажатия.", Toast.LENGTH_LONG).show()
            }
        }

        val finishButton = Button(this).apply {
            text = "✓ ЗАКОНЧИТЬ ОБУЧЕНИЕ И СОХРАНИТЬ"
            isEnabled = X5AccessibilityService.instance?.isTraining() == true
            setOnClickListener {
                val service = X5AccessibilityService.instance
                if (service?.isTraining() != true) {
                    Toast.makeText(this@MainActivity, "Обучение сейчас не запущено.", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                service.finishTraining()
                ScenarioStore.save(this@MainActivity, scenarios)
                status.text = "● ГОТОВ — СЦЕНАРИЙ СОХРАНЕН"
                updateActionInfo()
                Toast.makeText(this@MainActivity, "Сценарий сохранён: ${s.actions.size} действий", Toast.LENGTH_SHORT).show()
                settingsDialog?.dismiss()
            }
        }

        val trainingHelp = TextView(this).apply {
            text = "Обучение полностью вынесено из главного экрана. После начала перейди в X5. Для завершения снова открой Настройки и нажми кнопку сохранения."
            textSize = 13f
            setPadding(0, 12, 0, 8)
        }

        layout.addView(intervalTitle)
        layout.addView(intervalHelp)
        layout.addView(interval)
        layout.addView(stopTitle)
        layout.addView(stopHelp)
        layout.addView(stop)
        layout.addView(actionsTitle)
        layout.addView(trainingHelp)
        layout.addView(trainButton)
        layout.addView(finishButton)

        settingsDialog = AlertDialog.Builder(this)
            .setTitle("Настройки: ${s.name}")
            .setView(layout)
            .setPositiveButton("Сохранить") { _, _ ->
                s.intervalMs = interval.text.toString().toLongOrNull()?.coerceAtLeast(50) ?: 1000
                s.stopText = stop.text.toString().trim().ifBlank { "Московская область, Егорьевск, 4-й мкр, 21А" }
                ScenarioStore.save(this, scenarios)
                updateActionInfo()
            }
            .setNegativeButton("Отмена", null)
            .create()
        settingsDialog?.setOnDismissListener { settingsDialog = null }
        settingsDialog?.show()
    }

    private fun showScenarioEditor() {
        val s = scenarios[spinner.selectedItemPosition.coerceIn(0, scenarios.lastIndex)]
        val items = if (s.actions.isEmpty()) arrayOf("Пока нет записанных действий") else s.actions.mapIndexed { i, a ->
            val target = a.text?.takeIf { it.isNotBlank() }
                ?: a.description?.takeIf { it.isNotBlank() }
                ?: a.className ?: "Координатное нажатие"
            "${i + 1}. $target — пауза ${a.delayMs} мс"
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Редактор: ${s.name}")
            .setItems(items) { _, which -> if (s.actions.isNotEmpty()) showActionEditor(s, which) }
            .setNeutralButton("Переименовать") { _, _ -> showRenameScenario(s) }
            .setNegativeButton("Удалить сценарий") { _, _ ->
                if (scenarios.size <= 1) {
                    Toast.makeText(this, "Нельзя удалить последний сценарий.", Toast.LENGTH_SHORT).show()
                } else {
                    scenarios.removeAt(spinner.selectedItemPosition)
                    ScenarioStore.save(this, scenarios)
                    refreshSpinner()
                    Toast.makeText(this, "Сценарий удалён", Toast.LENGTH_SHORT).show()
                }
            }
            .setPositiveButton("Готово", null)
            .show()
    }

    private fun showActionEditor(s: Scenario, index: Int) {
        if (index !in s.actions.indices) return
        val a = s.actions[index]
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 10, 40, 0)
        }
        val details = TextView(this).apply {
            text = "Текст: ${a.text ?: "—"}\nОписание: ${a.description ?: "—"}\nКласс: ${a.className ?: "—"}\nКоординаты: ${a.bounds.left}, ${a.bounds.top} → ${a.bounds.right}, ${a.bounds.bottom}"
            textSize = 13f
        }
        val delay = EditText(this).apply {
            hint = "Задержка перед действием, мс"
            setText(a.delayMs.toString())
            inputType = 2
        }
        layout.addView(details)
        layout.addView(delay)
        AlertDialog.Builder(this)
            .setTitle("Действие №${index + 1}")
            .setView(layout)
            .setPositiveButton("Сохранить") { _, _ ->
                val newDelay = delay.text.toString().toLongOrNull()?.coerceIn(0, 60000) ?: a.delayMs
                s.actions[index] = a.copy(delayMs = newDelay)
                ScenarioStore.save(this, scenarios)
                updateActionInfo()
                showScenarioEditor()
            }
            .setNegativeButton("Удалить действие") { _, _ ->
                s.actions.removeAt(index)
                ScenarioStore.save(this, scenarios)
                updateActionInfo()
                showScenarioEditor()
            }
            .setNeutralButton("Отмена", null)
            .show()
    }

    private fun showRenameScenario(s: Scenario) {
        val input = EditText(this).apply { setText(s.name); selectAll() }
        AlertDialog.Builder(this)
            .setTitle("Название сценария")
            .setView(input)
            .setPositiveButton("Сохранить") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotBlank()) {
                    s.name = name
                    ScenarioStore.save(this, scenarios)
                    refreshSpinner()
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun refreshSpinner() {
        val oldPosition = if (::spinner.isInitialized) spinner.selectedItemPosition else 0
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, scenarios.map { it.name })
        spinner.setSelection(oldPosition.coerceIn(0, scenarios.lastIndex))
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) { updateActionInfo() }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
    }

    private fun updateActionInfo() {
        if (!::info.isInitialized || scenarios.isEmpty()) return
        val s = scenarios[spinner.selectedItemPosition.coerceIn(0, scenarios.lastIndex)]
        info.text = "Записанных действий: ${s.actions.size}\nИнтервал между циклами: ${s.intervalMs} мс"
    }

    private fun isAccessibilityEnabled(): Boolean {
        val am = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.packageName == packageName }
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) {
            val service = X5AccessibilityService.instance
            status.text = when {
                service?.isTraining() == true -> "● ИДЕТ ОБУЧЕНИЕ"
                service?.isRunning() == true -> "● КЛИКЕР РАБОТАЕТ"
                else -> "● ГОТОВ"
            }
        }
        updateActionInfo()
    }
}
