package ru.x5autoclicker

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var spinner: Spinner
    private lateinit var status: TextView
    private lateinit var info: TextView
    private lateinit var scenarios: MutableList<Scenario>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        scenarios = ScenarioStore.load(this)
        spinner = findViewById(R.id.scenarioSpinner)
        status = findViewById(R.id.status)
        info = findViewById(R.id.info)
        refreshSpinner()

        findViewById<Button>(R.id.startButton).setOnClickListener {
            val s = scenarios[spinner.selectedItemPosition]
            if (!isAccessibilityEnabled()) {
                Toast.makeText(this, "Сначала включи X5 Auto Clicker в специальных возможностях.", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                return@setOnClickListener
            }
            X5AccessibilityService.instance?.start(s)
            status.text = "● ЛОВЛЯ МАГАЗИНА ЗАПУЩЕНА"
        }
        findViewById<Button>(R.id.stopButton).setOnClickListener {
            X5AccessibilityService.instance?.stop()
            status.text = "● ОСТАНОВЛЕН"
        }
        findViewById<Button>(R.id.trainButton).setOnClickListener {
            if (!isAccessibilityEnabled()) {
                Toast.makeText(this, "Включи службу специальных возможностей.", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                return@setOnClickListener
            }
            val s = scenarios[spinner.selectedItemPosition]
            X5AccessibilityService.instance?.startRecording(s)
            Toast.makeText(this, "Запись началась. Перейди в X5 и нажимай кнопки. После записи вернись сюда и нажми СТОП/сохрани сценарий.", Toast.LENGTH_LONG).show()
        }
        findViewById<Button>(R.id.settingsButton).setOnClickListener { showSettings() }
    }

    private fun refreshSpinner() {
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, scenarios.map { it.name })
    }

    private fun showSettings() {
        val s = scenarios[spinner.selectedItemPosition]
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40,20,40,10) }
        val interval = EditText(this).apply { hint = "Интервал между циклами, мс"; setText(s.intervalMs.toString()); inputType = 2 }
        val stop = EditText(this).apply { hint = "Текст для остановки"; setText(s.stopText) }
        layout.addView(interval); layout.addView(stop)
        AlertDialog.Builder(this).setTitle("Настройки сценария").setView(layout)
            .setPositiveButton("Сохранить") { _, _ ->
                s.intervalMs = interval.text.toString().toLongOrNull()?.coerceAtLeast(50) ?: 1000
                s.stopText = stop.text.toString()
                ScenarioStore.save(this, scenarios)
            }.setNegativeButton("Отмена", null).show()
    }

    private fun isAccessibilityEnabled(): Boolean {
        val am = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.packageName == packageName }
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized && X5AccessibilityService.instance != null) {
            info.text = "Служба доступна"
        }
    }
}
